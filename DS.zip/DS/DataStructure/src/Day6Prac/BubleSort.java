package Day6Prac;

public class BubleSort {
	
	static void bubbleSort(int a[]) {
	int i,j,t;	
	for(i=0;i<a.length-1;i++)
	{
		for(j=0;j<a.length-1;j++)
		{
			if(a[j]>a[j+1])
			{
				t= a[j];
				a[j]= a[j+1];
				a[j+1] = t;
				
			}
		}
	}
		
		
	}
	
	static void printArray(int a[]) {
		
		for(int i=0;i<a.length;i++)
			System.out.print(a[i]+ ",");
	}
	
	public static void main(String args[])
	 {
	     int a[]={55,11,77,33,22,99,88,44,66};
	     System.out.println("Befor Sort:");
	     BubleSort.printArray(a);
	     BubleSort.bubbleSort(a);
	     //Sorting.BubbleSort_V2(a);
	     System.out.println("\nAfter Sort:");
	     BubleSort.printArray(a);

	 }
	
	

}
