package Day6Prac;

public class Searching {
	
 static int	LinearSearch(int a[],int key)
  {
		
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==key)
			{
				return i;
			}
		}
		
		return -1;
  }
 
    static int BinarySerach(int a[], int start,int end,int key){
    	if(start<=end)
    	{
    		int mid=(start+end)/2;
    		if(key==a[mid])
    			return mid;
    	
    	else
    	{
    		if(key<mid)
    		
    			return BinarySerach(a, start,mid-1 ,key );
    		
    		else
    		
    			return BinarySerach(a, mid+1, end, key);
    		
    	}
    	
    }
    	else {
			return -1;
		}
  }
    	
    	 
     
 
  public static void main(String[] args)
   {
	
	  int a[]= {10,20,45,78,96,108,178,250};
	  int key = 20;
	///int re =  Searching.LinearSearch(a, key);
	  int re = Searching.BinarySerach(a, 0, a.length-1, key);
;
	  if(re==-1) 
	 {
		 System.out.println(key+ "Key not found");
	 }
	  else
	  {
		  System.out.println(key+ "Key is found");
	  }
	  
	  
   } 

}
