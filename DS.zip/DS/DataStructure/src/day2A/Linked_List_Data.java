 package day2A;

public class Linked_List_Data {

	 public static class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data = data;
			this.next= null;
		}
	}
}
