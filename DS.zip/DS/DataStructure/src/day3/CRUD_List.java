1package day3;

import java.util.Scanner;





public class CRUD_List {
	
	Enode root;
	 void createList()
	 {
	     root=null;
	 }
	 void insert(int eid,String name,String gender,int salary)
	 {
	     Enode n=new Enode(eid,name,gender,salary);
	     if(root==null)
	          root=n;
	      else
	      {
	         Enode t=root;//1
	         while(t.next!=null)//2
	             t=t.next;
	         t.next=n;//3
	      }
	     System.out.println("Inserted");
	 }
	 
	 void update(Enode t)
	 {
	          Scanner in=new Scanner(System.in);
	          System.out.println("\n1.Update name\n2.Update gender\n3.Update Salary:");
	          int i_ch=in.nextInt();
	          if(i_ch==1)
	          {
	                System.out.println("Old:"+t.name);
	                System.out.println("\nEnter new:");
	                t.name=in.next();
	          }
	          else if(i_ch==2)
	          {
	                System.out.println("Old:"+t.gender);
	                System.out.println("\nEnter new:");
	                t.gender=in.next();
	          }
	          else if(i_ch==3)
	          {
	                System.out.println("Old:"+t.salary);
	                System.out.println("\nEnter new:");
	                t.salary=in.nextInt();
	          }
	                System.out.println("\nupdated........");
	          }
	 
	 void printList()
	    {
	       if(root==null)
	          System.out.println("Empty List");
	      else
	      {
	          Enode t=root;
	          while(t!=null)
	          {
	              System.out.println(t.eid+","+t.name+","+t.gender+","+t.salary);
	              t=t.next;
	          }
	      }

	    }
	 
	 void delete(int eid) {
	        if (root == null)
	            return;
	        if (root.eid == eid) {
	            root = root.next;
	            return;
	        }
	        Enode t = root;
	        while (t.next != null) {
	            if (t.next.eid == eid) {
	                t.next = t.next.next;
	                return;
	            }
	            t = t.next;
	        }
	        System.out.println("Employee not found");
	    }
	 
	 Enode searchList(int key)
	    {
	       if(root==null)
	          System.out.println("Empty List");
	      else
	      {
	          Enode t=root;
	          while(t!=null && t.eid!=key)
	            t=t.next;
	          if(t==null)
	               System.out.println(key+" not found");
	          else if(t.eid==key)
	               System.out.println(key+" found int list");

	      }
		return null;
	    }
	    
 public static void main(String args[])
   {
	 Scanner in=new Scanner(System.in);
     CRUD_List obj=new CRUD_List();
     obj.createList();
     int ch;
     Enode t;
     do
     {
       System.out.println("\n1.Insert Emp \n2.Search \n3.Update\n4.Print \n5.Delete\n0.Exit\n:");
       ch=in.nextInt();//read
       switch(ch)
       {
           case 1:
                   System.out.println("\nEnter Employee Id, Name, Gender, Salary");
                   int e=in.nextInt();
                   obj.insert(e, in.next(), in.next(),in.nextInt());
                   break;
           case 2:
        	       System.out.println("Enter Employee ID to Search:");
        	       t= obj.searchList(in.nextInt());
        	       if(t!=null)
        	       {
        	        System.out.println(t.eid + "," + t.name + "," + t.gender + "," + t.salary);   
        	       }
        	       else
                       System.out.println("Employee not found");
                   break;
        	   
           case 3:
        	   System.out.println("Enter Employee ID to Update:");
               Enode toUpdate = obj.searchList(in.nextInt());
               if (toUpdate != null) {
                   obj.update(toUpdate);
               } else {
                   System.out.println("Employee not found");
               }
               break;
           case 5:
        	   System.out.println("Enter Employee ID to Delete:");
               obj.delete(in.nextInt());
               break;
           case 4:
                  System.out.println("print employee");
                  obj.printList();
                   break;
                   
                        
           case 0:
                   System.out.println("Exiting");
               break;
           default:
                   System.out.println("Wrong Choice");
               break;
       }
         
     }while(ch!=0);
  }
 }

