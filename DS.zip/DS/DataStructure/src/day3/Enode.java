package day3;

public class Enode {
	
	int eid;
	String name;
	String gender;
	int salary;
	Enode next;
	
	public Enode(int eid, String name, String gender, int salary) {
		
		this.eid = eid;
		this.name = name;
		this.gender = gender;
		this.salary = salary;
		next = null;
	}
	
	
}


