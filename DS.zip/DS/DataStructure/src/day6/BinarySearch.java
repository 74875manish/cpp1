package day6;

public class BinarySearch {
	
	static void BubbleSort(int a[ ])
	{
	  int i, j,t;
	  for(i=0;i<a.length-1;i++)//paases
	   {for(j=0;j<a.length-1;j++)
		//j stops at second last
		{
			if(a[j]>a[j+1])
	              {
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			 }
	       }
	   }
	}
	
	public static void main(String args[])
	 {
	     int a[]={11,66,22,99,33,88,77,44,55};
	     System.out.println("Befor Sort:");
	     Sorting.printArray(a);
	     Sorting.BubbleSort(a);
	     System.out.println("\nAfter Sort:");
	     Sorting.printArray(a);

	 }

	
		
}
