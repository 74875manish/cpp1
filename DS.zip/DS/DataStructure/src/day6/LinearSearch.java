package day6;

public class LinearSearch {
 
	static int linearSerch(int a[],int key) {
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==key)
			{
				return i;
			}
		}
		return -1;
		
	}
	
	public static void main(String[] args) {
		
		int a[]= {66,22,99,30,88,77,44,55};
		int key=666;
		int re=LinearSearch.linearSerch(a, key);
		if(re==-1)
		{
			System.out.println(key+ "key not found");
		}
		else {
			System.out.println(key+  "key is found");
		}
		
	}

}
