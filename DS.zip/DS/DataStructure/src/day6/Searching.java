package day6;

public class Searching {
	int linearSerach(int a[], int key)
	{
		for(int i =0;i<a.length)
	}
	
}
