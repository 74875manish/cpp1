package day5;

import java.util.Scanner;

public class Count {

	public static void main(String[] args) {
		
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter your String\n");
	String s = sc.nextLine();
	
	int i=0;
	int count_start =0;
	int count_Hash =0;
	
	for(i=0;i<s.length();i++)
	{
		char c = s.charAt(i);
		if(c=='*') {
			count_start++;
			
		}
		
		else if (c=='#')
		{
			count_Hash++;
			
		}
		
		
			
	}
	
	System.out.println("total number * " +count_start);
	System.out.println("total number # " +count_Hash);	
	System.out.println("Result = " +(count_start-count_Hash));
	}

}
