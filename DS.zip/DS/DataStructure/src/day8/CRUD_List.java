package day8;

import java.util.Scanner;

public class CRUD_List {
	
	Enode root;
	
	void createList() {
		
	root = null;
		
	}
	
	void insert(int emp_id, String name, String gender, double salary) {
		Enode n = new Enode(emp_id, name, gender, salary);
		if(root==null)
			root = n;
		else
		{
			Enode t = root;
			while(t.next!=null)
				t=t.next;
			t.next=n;
		}
		
		System.out.println(" data inserted");
			
	}

	
	 void update(Enode t) {
		 Scanner sc = new  Scanner(System.in);
		 System.out.println("1.update name \n2.update salary \n3.update gender");
		 int in= sc.nextInt();
	
	 }
	
	  
	  		  
	  
}
