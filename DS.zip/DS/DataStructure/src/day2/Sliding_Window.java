package day2;

import java.util.Scanner;

import day1.Stack_Example;

public class Sliding_Window {

	int MaxSize, front,rear,queqe[];
	
	
	void createQueqe(int size)
	{
		MaxSize = size;
		front = 0;
		rear = -1;
		queqe = new int[MaxSize];
		
		
		
		
		
	}
	
	void enqueue (int e) // entery on queue
	{  
		
		rear++;
		queqe[rear]=e;
		System.out.println("enqueed " +e);
	}
	
	boolean isFull()
	{
		if(rear ==MaxSize-1)
			return true;
		else 
			return false;
	}
	
	int  dequeue () {
		int temp = queqe[front];
		front++;
	   return temp;
	}
	
	boolean isEmpty()
	{
		if (front>rear)
			return true;
		else
			return false;
	}
	
	void printQueue()
    {
        System.out.println("Queue Has:");
        for(int i=front;i<=rear;i++)
            System.out.println(queqe[i]+ "-");
    }
	
	  void sliding_window(int size)
	     {
	         if((rear-front+1)<size)
	         {
	             int max=queqe[front];//ref
	             for(int i=front+1;i<=rear;i++)
	                 if(queqe[i]>max)
	                     max=queqe[i];
	             System.out.println("Max is window :"+max);
	         }
	         else
	         {
	           System.out.println("Max is window :");
	           for(int i=front;i<=rear-size+1;i++)
	           {
	               int max=queqe[i];
	               for(int j=i+1;j<=i+size-1;j++)
	               {
	                   if(queqe[j]>max)
	                       max=queqe[j];
	               }
	               System.out.print(max+",");
	           }
	     }
	     }
	
	
	
	
	public static void main(String args[])
    {
        int ch;
        Scanner in =new Scanner(System.in);
        Sliding_Window obj=new  Sliding_Window();
        System.out.print("Enter size of queqe:");
        int size=in.nextInt();
        obj.createQueqe(size);//creates array of size
        do
        {
            System.out.print("\n1.enqueue\n2.dequeue\n3.Print\n0.Exit\n:");
            ch=in.nextInt();
            switch(ch)
            {
                case 1:
                    if(obj.isFull()!=true)//if not full then push
                    {
                        System.out.print("Enter elment:");
                        int e=in.nextInt();
                        obj.enqueue(e);
                    }
                    else
                        System.out.print("enque Full");
                    break;
                case 2:
                    if(obj.isEmpty()!=true)//if not empty then pop
                    {
                        System.out.print("Element out:"+obj.dequeue());
                    }
                    else
                        System.out.print("Queque Empty");
                    break;
                
                case 3:
                    if(obj.isEmpty()!=true)//if not empty then pop
                    {
                      obj.printQueue();
                    }
                    else
                        System.out.print("Queque Empty");
                    break;
                    
                case 4:
                    if(!obj.isEmpty())
                     {
                       System.out.println("Window size");
                       size=in.nextInt();
                       obj.sliding_window(size);
                     }
                    else
                       System.out.println("Queue is Empty");
                   break;
                	
                case 0:
                        System.out.print("Exiting code");
                        break;
                default:
                        System.out.print("Wrong input");
                        break;
            }
        }while(ch!=0);
    
    }
	
 
	
}
